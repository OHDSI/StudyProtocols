TRUNCATE TABLE #cohort_person;

DROP TABLE #cohort_person;
