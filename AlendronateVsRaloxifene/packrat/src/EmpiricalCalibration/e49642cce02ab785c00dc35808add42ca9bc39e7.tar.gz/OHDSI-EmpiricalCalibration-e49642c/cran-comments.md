This is an update of the package

NEW FEATURES

* Ability to add credible intervals to calibration effect plot

* Plot CI calibration (using leave-one-out cross-validation)

BUG FIXES

* Fixed vignette name in index

* Removed coverage plot (moved to MethodEvaluation package)

---

## Test environments
* Ubuntu 12.04.5 LTS (Travis), R 3.2.5
* Windows 7, R 3.3.1
* win-builder

## R CMD check results

There were no ERRORs or WARNINGs. 

## Downstream dependencies

There are currently no downstream dependencies.