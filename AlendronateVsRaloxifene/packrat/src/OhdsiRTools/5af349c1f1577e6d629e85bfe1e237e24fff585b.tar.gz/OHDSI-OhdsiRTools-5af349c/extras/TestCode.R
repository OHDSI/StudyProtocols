insertCohortDefinitionInPackage(definitionId = 3876, 
                                name = "Alendronate",
                                generateStats = TRUE)




insertCohortDefinitionSetInPackage(fileName = "cohorts.csv",
                                   insertTableSql = TRUE,
                                   insertCohortCreationR = TRUE,
                                   generateStats = FALSE,
                                   packageName = "OhdsiRTools")



