library(testthat)
library(FeatureExtraction)

test_check("FeatureExtraction")
