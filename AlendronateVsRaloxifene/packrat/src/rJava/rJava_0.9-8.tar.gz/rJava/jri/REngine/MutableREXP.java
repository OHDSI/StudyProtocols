package org.rosuda.REngine;

public interface MutableREXP {
	public void setAttribute(String name, REXP value);
}
