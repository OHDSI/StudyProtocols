UUIDgenerate <- function(use.time = NA) .Call(UUID_gen, use.time)
